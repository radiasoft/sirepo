// from sirepo_test_dynamics_sim_type
// jshint ignore: start
SIREPO.authState = {{ auth_state | tojson }};
