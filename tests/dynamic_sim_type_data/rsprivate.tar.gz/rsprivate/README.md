### rsprivate

super secret repo

Learn more at https://github.com/radiasoft/rsprivate.

Documentation: http://rsprivate.readthedocs.org/en/latest/

#### License

License: http://www.apache.org/licenses/LICENSE-2.0.html

Copyright (c) 2021 RadiaSoft LLC.  All Rights Reserved.


Interesting things:
- /auth-state overrides sirepo auth-state and renders a jinja template
- put a raise_forbidden('foo') in `api_listSimulations` to see rsprivate forbidden message
- /favicon.ico uses a different rsprivate icon
