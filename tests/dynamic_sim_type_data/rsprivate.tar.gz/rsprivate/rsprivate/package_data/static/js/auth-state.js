// from rsprivate
// jshint ignore: start
SIREPO.authState = {{ auth_state | tojson }};
