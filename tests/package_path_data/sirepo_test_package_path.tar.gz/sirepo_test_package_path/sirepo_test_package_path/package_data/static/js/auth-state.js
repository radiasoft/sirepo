// from sirepo_test_package_path
// jshint ignore: start
SIREPO.authState = {{ auth_state | tojson }};
