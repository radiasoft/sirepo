### sirepo_test_package_path

super secret repo

Interesting things:
- /auth-state overrides sirepo auth-state and renders a jinja template
- put a raise_forbidden('foo') in `api_listSimulations` to see sirepo_test_package_path forbidden message
- /favicon.ico uses a different sirepo_test_package_path icon
