// from sirepo_test_root_packages
// jshint ignore: start
SIREPO.authState = {{ auth_state | tojson }};
